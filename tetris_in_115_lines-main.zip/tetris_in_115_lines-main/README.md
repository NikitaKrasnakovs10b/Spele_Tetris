# Tetris In 115 Lines Of Code

Source Code from the [Building TETRIS in 115 LINES of python code](https://www.youtube.com/watch?v=jJv42f0g9to&t=1s)
